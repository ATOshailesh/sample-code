//
//  AIReachabilityManager.swift
// EduCanada

import Foundation
import ReachabilitySwift


class AIReachabilityManager: NSObject {
	
	private let reachability = Reachability()!
	private var isFirstTimeSetupDone:Bool = false
	private var callCounter:Int = 0
	
	// MARK: - SHARED MANAGER
	static let shared: AIReachabilityManager = AIReachabilityManager()

	
	//MARK:- ALL NETWORK CHECK
	func isInternetAvailableForAllNetworks() -> Bool {
		if(!self.isFirstTimeSetupDone){
			self.isFirstTimeSetupDone = true
			doSetupReachability()
		}
		return reachability.isReachable || reachability.isReachableViaWiFi || reachability.isReachableViaWWAN
	}
	
	
	//MARK:- SETUP
	private func doSetupReachability() {
	
		reachability.whenReachable = { reachability in
			DispatchQueue.main.async {
				self.postIntenetReachabilityDidChangeNotification(isInternetAvailable: true)
			}
		}
		reachability.whenUnreachable = { reachability in
			DispatchQueue.main.async {
				self.postIntenetReachabilityDidChangeNotification(isInternetAvailable: false)
			}
		}
		do{
			try reachability.startNotifier()
		}catch{
		}
	}
	
	deinit {
		reachability.stopNotifier()
		NotificationCenter.default.removeObserver(self, name: ReachabilityChangedNotification, object: nil)
	}

	
	
	//MARK:- NOTIFICATION
	private func postIntenetReachabilityDidChangeNotification(isInternetAvailable isAvailable:Bool){
//		print("\n\n")
//		print("NET REACHABILITY CHANGED : \(isAvailable)")
		
		DispatchQueue.main.async {
			
			if(isAvailable){
				// TO AVOID INITIAL ALERT
				if(self.callCounter != 0){
                    print("User Online.")
                    AIAutoUpload.shared.uploadOfflineData()
//                    AIAlertController.shared.displayAlertWithTitle(title: APPNAME, andMessage: "You are now online".localized(), buttons: ["OK"], completion: { (index) in
//
//                    })
                    
				}
			}else{
                print("User Offline.")
//                AIAlertController.shared.displayAlertWithTitle(title: APPNAME, andMessage: "You are now offline".localized(), buttons: ["OK"], completion: { (index) in
//
//                })
			}
			self.callCounter += 1
			
			NotificationCenter.default.post(NSNotification(name: ReachabilityChangedNotification, object: nil) as Notification)

		}
		
	}
}
