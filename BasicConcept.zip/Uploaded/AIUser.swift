//
//  AIUser.swift
//  carsumar project

import UIKit

class AIUser: NSObject,Codable {
    
    enum CodingKeys: String, CodingKey {
    
        case user_id
        case user_name
        case email
        case password
        case mobile_number
        case image_id
        case address
        case city
        case state
        case zipcode
        case user_type
        case is_active
        case created
        case updated
        case profile_picture
        case access_token
    }
    
    var user_id         : String = ""
    var user_name       : String = ""
    var email           : String = ""
    var password        : String = ""
    var mobile_number   : String = ""
    var image_id        : String = ""
    var address         : String = ""
    var city            : String = ""
    var state           : String = ""
    var zipcode         : String = ""
    var user_type       : String = ""
    var is_active       : String = ""
    var created         : String = ""
    var updated         : String = ""
    var profile_picture : String = ""
    var access_token    : String = ""
    
//    var device_token     :String = ""
//    var device_id        :String = ""
    
    var currentUser:AIUser!

    //MARK: - SHARED USER
    
    static let sharedManager = AIUser()
    
    //MARK: - Encode
    
    func encode(to encoder: Encoder) throws
    {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(user_id, forKey: .user_id)
        try container.encode(user_name, forKey: .user_name)
        try container.encode(email, forKey: .email)
        try container.encode(password, forKey: .password)
        try container.encode(mobile_number, forKey: .mobile_number)
        try container.encode(image_id, forKey: .image_id)
        try container.encode(address, forKey: .address)
        try container.encode(city, forKey: .city)
        try container.encode(state, forKey: .state)
        try container.encode(zipcode, forKey: .zipcode)
        try container.encode(user_type, forKey: .user_type)
        try container.encode(is_active, forKey: .is_active)
        try container.encode(created, forKey: .created)
        try container.encode(updated, forKey: .updated)
        try container.encode(profile_picture, forKey: .profile_picture)
        try container.encode(access_token, forKey: .access_token)
    }
    
    //MARK: - Decode
    
    required init(from decoder: Decoder) throws
    {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        user_id         = try container.decode(String.self,  forKey: .user_id)
        user_name       = try container.decode(String.self,  forKey: .user_name)
        email           = try container.decode(String.self,  forKey: .email)
        password        = try container.decode(String.self,  forKey: .password)
        mobile_number   = try container.decode(String.self,  forKey: .mobile_number)
        image_id        = try container.decode(String.self,  forKey: .image_id)
        address         = try container.decode(String.self,  forKey: .address)
        city            = try container.decode(String.self,  forKey: .city)
        state           = try container.decode(String.self,  forKey: .state)
        zipcode         = try container.decode(String.self,  forKey: .zipcode)
        user_type       = try container.decode(String.self,  forKey: .user_type)
        is_active       = try container.decode(String.self,  forKey: .is_active)
        created         = try container.decode(String.self,  forKey: .created)
        updated         = try container.decode(String.self,  forKey: .updated)
        profile_picture = try container.decode(String.self,  forKey: .profile_picture)
        access_token    = try container.decode(String.self,  forKey: .access_token)
    }
    
    override init() {
        
    }
    
    func setvalueUserWithdetails(dict : NSDictionary) -> Void {
        
        user_id         = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.user_id)
        user_name       = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.user_name)
        email           = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.email)
        password        = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.password)
        mobile_number   = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.mobile_number)
        image_id        = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.image_id)
        address         = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.address)
        city            = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.city)
        state           = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.state)
        zipcode         = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.zipcode)
        user_type       = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.user_type)
        is_active       = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.is_active)
        created         = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.created)
        updated         = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.updated)
        profile_picture = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.profile_picture)
        
        let strAccessToken = dict.object_forKeyWithValidationForClass_String(aKey: Key.User.access_token)
        if strAccessToken.isEmpty {

        }else{
            access_token    = strAccessToken
        }
        
        
    }
    
    // MARK: - SAVE
    
    func saveInDefaults()
    {
        do {
            let data = try PropertyListEncoder().encode(self)
            let encodeData = NSKeyedArchiver.archivedData(withRootObject: data)
            UserDefaults.standard.set(encodeData, forKey: Constant.Keys.KEY_IS_USER_LOGGED_IN)
            UserDefaults.standard.synchronize()
            
        } catch {
            print("Save Failed")
        }
    }
    
    //MARK: - CHECK LOGIN STATUS
    var isLoggedIn:Bool {
        get {
            return getUserDefaultsForKey(key: Constant.Keys.KEY_IS_USER_LOGGED_IN) != nil
        }
    }
    
    func isLoggedin() -> Bool
    {
        return UserDefaults.standard.object(forKey: Constant.Keys.KEY_IS_USER_LOGGED_IN) != nil ? true : false
    }
    
    // MARK: - Retrive Data
    
    func retriveData() -> AIUser?
    {
        let encodedObject : Data? = UserDefaults.standard.object(forKey: Constant.Keys.KEY_IS_USER_LOGGED_IN) as? Data
        if encodedObject != nil
        {
            guard let data = NSKeyedUnarchiver.unarchiveObject(with: encodedObject!) else {
                return nil
            }
            do{
                let user : AIUser = try PropertyListDecoder().decode(AIUser.self, from: data as! Data)
                return user
            }
            catch{
                print("retrived failed")
                return nil
            }
        }else
        {
            return nil
        }
    }
    
    // MARK: - load user
    
    func loadSavedUser()
    {
        let objuser : AIUser? = self .retriveData()
       
        user_id         = (objuser?.user_id)!
        user_name       = (objuser?.user_name)!
        email           = (objuser?.email)!
        password        = (objuser?.password)!
        mobile_number   = (objuser?.mobile_number)!
        image_id        = (objuser?.image_id)!
        address         = (objuser?.address)!
        city            = (objuser?.city)!
        state           = (objuser?.state)!
        zipcode         = (objuser?.zipcode)!
        user_type       = (objuser?.user_type)!
        is_active       = (objuser?.is_active)!
        created         = (objuser?.created)!
        updated         = (objuser?.updated)!
        profile_picture = (objuser?.profile_picture)!
        access_token    = (objuser?.access_token)!
    }
    
    // MARK: - LOGOUT
    
    func logout() -> Void
    {
       
        user_id         =   ""
        user_name       =   ""
        email           =   ""
        password        =   ""
        mobile_number   =   ""
        image_id        =   ""
        address         =   ""
        city            =   ""
        state           =   ""
        zipcode         =   ""
        user_type       =   ""
        is_active       =   ""
        created         =   ""
        updated         =   ""
        profile_picture =   ""
        access_token    =   ""

        
        UserDefaults.standard.removeObject(forKey: Constant.Keys.KEY_IS_USER_LOGGED_IN)
        UserDefaults.standard.synchronize()
    }
    
}
