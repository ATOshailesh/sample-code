//
//  AITextField.swift
//  EduCanada Project


import Foundation
import UIKit
import PureLayout

//MARK:- CONSTANTS
let MINIMUM_CHAR_VALUE = 2
let MAXIMUM_CHAR_VALUE = 256

let MINIMUM_CHAR_Price = 0
let MAXIMUM_CHAR_Price = 5

let MINIMUM_CHAR_Worker = 0
let MAXIMUM_CHAR_Worker = 3

let maxLimitForName = 50

let maxLimitForPassword = 15
let minLimitForPassword = 6

let minLimitForPhone = 8
let maxLimitForPhone = 16

let maxKmLimit = 3

let maxLimitForPrice = 9

class AITextField: SkyFloatingLabelTextField,UITextFieldDelegate {
    
    //MARK: - PROPERTIES
    //MARk: -
    var shouldAllowCopyPaste : Bool = true  //to allow copy paste in given field
    var stopKeyBoardToOpen:Bool = false     //to stop keyboard to be open
    
    var viewBottomLine = UIView()
    var buttonLeftPadding = AIButton()
    var buttonRightPadding = AIButton()
    @IBInspectable var strLeftImageName : String?
    @IBInspectable var strRightImageName : String?
    var verticalCenterConstraintPlaceholderLabel : NSLayoutConstraint?
    var minLength : Int = 0
    var maxLength : Int = 256
    
    var textFieldType : AITextFieldType = .Text{
        didSet{
            switch textFieldType {
            case .Password:
                self.isSecureTextEntry = true
                break
                
            default:
                break
            }
        }
    }

     //MARK: - BLOCK CALLS TO PASS EVENTS
    /*--------------- BLOCK CALLS OF TEXTFIELD DELEGATES-------------------*/
    
    var blockCallFor_textFieldEditChange : ((_ txtField:AITextField) -> Void)?
    var blockCallFor_textFieldDidEndEditing : ((_ txtField:AITextField) -> Void)?
    var blockCallFor_textFieldSDidBeginEditing : ((_ txtField:AITextField) -> Void)?
    var blockCallFor_textFieldShouldChangeCharactersInRange :((_ txtField: AITextField) -> Void)?
    var blockCallFor_textFieldShouldBeginEditing :((_ txtField: AITextField) -> Void)?

    //MARK: - TEXTFIELD LIFE CYCLE
    //MARK: -
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        
        if (self.textFieldType == .Password || self.textFieldType == .Place || self.textFieldType == .Hours || self.textFieldType == .Price) && (action == #selector(self.paste(_:))) {
            return self.shouldAllowCopyPaste
        }else if (self.textFieldType == .Password || self.textFieldType == .Place || self.textFieldType == .Hours || self.textFieldType == .Price) && (action == #selector(self.cut(_:))){
            return self.shouldAllowCopyPaste
        }
        else {
            return super.canPerformAction(action, withSender: sender)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if self.leftView == nil {
            if self.strLeftImageName != nil, (self.strLeftImageName?.whiteSpaceTrimmedString().characters.count)! > 0 {
                self.buttonLeftPadding.frame = CGRect(x: 0, y: 0, width: (getProportionalHeight(100)), height: (getProportionalHeight(100)))
                self.buttonLeftPadding.setImage(UIImage(named: self.strLeftImageName!), for: .normal)
                //self.leftView = self.buttonLeftPadding
                self.leftViewMode = .always
            }else {
                self.buttonLeftPadding.frame = CGRect(x: 0, y: 0, width: 10, height: self.height)
                //self.leftView = self.buttonLeftPadding
                self.leftViewMode = .always
            }
        }
        
        if self.rightView == nil {
            if self.strRightImageName != nil, (self.strRightImageName?.whiteSpaceTrimmedString().characters.count)! > 0 {
                self.buttonRightPadding.frame = CGRect(x: 0, y: 0, width: self.frame.size.height, height: self.frame.size.height)
                self.buttonRightPadding.setImage(UIImage(named: self.strRightImageName!), for: .normal)
                self.rightView = self.buttonRightPadding
                self.rightViewMode = .always
            }
        }
        
    }
    
    func setTextFieldType(tFieldType : AITextField)
    {
        //        self.textFieldType = tFieldType.textFieldType
        switch self.textFieldType {
        case .Text:
            self.minLength = MINIMUM_CHAR_VALUE
            self.maxLength = MAXIMUM_CHAR_VALUE
            self.keyboardType = .namePhonePad
            self.setReturnKeyForTextField()
            break
            
        case .CompanyName:
            self.minLength = MINIMUM_CHAR_VALUE
            self.maxLength = maxLimitForName
            self.keyboardType = .default
            self.setReturnKeyForTextField()
            
        case .Email:
            self.keyboardType = .emailAddress
            self.setReturnKeyForTextField()
            break
            
        case .Password:
            self.minLength = minLimitForPassword
            self.maxLength = maxLimitForPassword
            self.isSecureTextEntry = true
            self.shouldAllowCopyPaste = false
            self.setReturnKeyForTextField()
            break
            
        case .Phone:
            self.minLength = minLimitForPhone
            self.maxLength = maxLimitForPhone
            self.keyboardType = .phonePad
            self.setReturnKeyForTextField()
            break
            
        case .Name:
            self.minLength = MINIMUM_CHAR_VALUE
            self.maxLength = maxLimitForName
            self.keyboardType = .namePhonePad
            self.setReturnKeyForTextField()
            break
            
        case .Place:
            self.stopKeyBoardToOpen = true
            self.tintColor = UIColor.clear
            self.shouldAllowCopyPaste = false
            break
            
        case .FullName:
            self.minLength = MINIMUM_CHAR_VALUE
            self.maxLength = maxLimitForName
            self.keyboardType = .default
            self.setReturnKeyForTextField()
            break
            
        case .WorkRadiusInkm:
            self.minLength = MINIMUM_CHAR_VALUE
            self.maxLength = maxKmLimit
            self.keyboardType = .phonePad
            self.setReturnKeyForTextField()
            break
            
        case .Price:
            self.minLength = MINIMUM_CHAR_Price
            self.maxLength = MAXIMUM_CHAR_Price
            self.keyboardType = .phonePad
            self.setReturnKeyForTextField()
            self.shouldAllowCopyPaste = false
            break
            
        case .AlphaNumeric:
            self.minLength = MINIMUM_CHAR_VALUE
            self.maxLength = maxLimitForName
            self.keyboardType = .default
            self.setReturnKeyForTextField()
            break
            
        case .SearchLocation:
            self.stopKeyBoardToOpen = true
            self.tintColor = UIColor.clear
            self.shouldAllowCopyPaste = false
            break
            
        case .SearchJob:
            self.stopKeyBoardToOpen = true
            self.tintColor = UIColor.clear
            self.shouldAllowCopyPaste = false
            break
            
        default:
            break
        }
    }
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        var rect:CGRect = super.textRect(forBounds: bounds)
        if(self.isRightViewAvailable()){
            rect.size.width = rect.size.width  - self.frame.size.height
        }
        return rect
    }
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        var rect:CGRect = super.editingRect(forBounds: bounds)
        if(self.isRightViewAvailable()){
            rect.size.width = rect.size.width  - self.frame.size.height
        }
        return rect
    }
    
    
    // MARK: - BUTTON HANDLER
    // MARK: -
    func buttonCancelPressed()
    {
        self.resignFirstResponder()
    }
    
    func buttonNextPressed()
    {
        _ = self.delegate?.textFieldShouldReturn!(self)
    }
    
    
    
    // MARK: PLACEHOLDER
    // MARK:
    func configurePlaceholder() {
        
        if(self.placeholder != nil){
            if (self.placeholder?.whiteSpaceTrimmedString().characters.count)! > 0 {
                self.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
            }
        }
    }
    
    // MARK: LENGTH VALIDATIONS
    // MARK:
    func setUpTextFieldLenghtValidation(minimumLength: Int, maximumLength : Int)
    {
        self.minLength = minimumLength
        self.maxLength = maximumLength
    }
    
    //MARK: - SET FORMET UI
    //MARk: -
    func setupUI() {
        self.font = UIFont.regularFontOfSize(ofSize: (self.font?.pointSize)!)
        
        self.textColor = UIColor.appBlackColor
        self.backgroundColor = UIColor.clear
        
        self.tintColor = UIColor.appThemeColor
        
//        self.selectedTitleColor = UIColor.appTextLightGrayColor
        
        self.clipsToBounds = false
        
        self.autocorrectionType = .no
        
        // ADD BOTTOM LINE
        self.viewBottomLine = self.viewWithTag(111) ?? UIView()
        self.viewBottomLine.backgroundColor = UIColor.appSeperatorColor
        
        if self.viewWithTag(111) == nil {
            self.viewBottomLine.tag = 111
            self.addSubview(self.viewBottomLine)
            self.viewBottomLine.autoPinEdgesToSuperviewEdges(with: .zero, excludingEdge: .top)
            self.viewBottomLine.autoSetDimension(.height, toSize: 1.0)
        }
        
        // LEFT PADDING IMAGE VIEW
        self.buttonLeftPadding.frame = CGRect(x: 0, y: 0, width: self.frame.size.height, height: self.frame.size.height)
        self.buttonLeftPadding.isUserInteractionEnabled = false
        self.buttonLeftPadding.isEnabled = false
        
        self.buttonRightPadding.frame = CGRect(x: 0, y: 0, width: self.frame.size.height, height: self.frame.size.height)
        self.buttonRightPadding.isUserInteractionEnabled = false
        self.buttonRightPadding.isEnabled = false
        
        
        self.configurePlaceholder()
        
        // DELEGATE
        self.delegate = self;
        
        // RETURN KEY TYPE
        self.returnKeyType = .done
        self.setReturnKeyForTextField()
    }
    
    
    //MARK: - TEXT DID CHANGE EVENT
    //MARk: -
    func textDidChange() {
        if(self.blockCallFor_textFieldEditChange != nil){
            self.blockCallFor_textFieldEditChange!(self)
        }
    }
    
    //MARK: - GENERAL METHODS
    //MARK: -
    func isRightViewAvailable() -> Bool{
        if(self.strRightImageName != nil){
            return true
        }
        return false
    }
    
    
    func setReturnKeyForTextField() {
        let aaa = self.getViewWithTag(aTag: self.tag + 1)
        if aaa != nil {
            self.returnKeyType = .next
        }
        
        
        if(self.keyboardType == .numberPad || self.keyboardType == .decimalPad || self.keyboardType == .phonePad)
        {
            // TOOLBAR
            let toolBar = UIToolbar()
            toolBar.frame = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 44)
            toolBar.barTintColor = UIColor.appThemeColor
            toolBar.isTranslucent = true
            
            // TOOLBAR ITEMS
            let buttonNext : UIButton = UIButton.init(frame:CGRect.zero)
            buttonNext.setTitle("Done", for: .normal)
            if self.getViewWithTag(aTag: self.tag + 1) != nil {
                buttonNext.setTitle("Next", for: .normal)
            }
            buttonNext.titleLabel?.font = UIFont.mediumFontOfSize(ofSize: 16.0) //semiBoldFontOfSize(size: 16.0)
            buttonNext.setTitleColor(UIColor.appWhiteColor, for: .normal)
            buttonNext.addTarget(self, action:#selector(AITextField.buttonNextPressed), for: .touchUpInside)
            buttonNext.sizeToFit()
            
            let buttonCancel : UIButton = UIButton()
            buttonCancel.setTitle("Cancel".localized(), for: .normal)
            buttonCancel.titleLabel?.font = UIFont.mediumFontOfSize(ofSize: 16.0)
            buttonCancel.setTitleColor(UIColor.appWhiteColor, for: .normal)
            buttonCancel.addTarget(self, action: #selector(AITextField.buttonCancelPressed), for: .touchUpInside)
            buttonCancel.sizeToFit()
            
            let barButtonCancel = UIBarButtonItem(customView: buttonCancel)
            let barButtonNext = UIBarButtonItem(customView: buttonNext)
            let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            
            toolBar.items = [barButtonCancel,flexibleSpace, barButtonNext]
            self.inputAccessoryView = toolBar
        }
        
    }
    
    
    //MARK: - TextField Delegate methods
    //MARK: -
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.buttonLeftPadding.isEnabled = true
        
        if (self.blockCallFor_textFieldSDidBeginEditing != nil) {
            self.blockCallFor_textFieldSDidBeginEditing!(textField as! AITextField)
        }
        
        self.setTextFieldType(tFieldType: textField as! AITextField)
        
    }
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.setTextFieldType(tFieldType: textField as! AITextField)
        
        if(self.stopKeyBoardToOpen){
            self.resignFirstResponder()
        }
        
        if (self.blockCallFor_textFieldShouldBeginEditing != nil) {
            self.blockCallFor_textFieldShouldBeginEditing!(textField as! AITextField)
        }
        
        
        return !self.stopKeyBoardToOpen
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var shouldReturn: Bool = true
        
        // BACKSPACE ALLOWED ALWAYS
        if(string == "") {
            if (self.blockCallFor_textFieldShouldChangeCharactersInRange != nil) {
                self.blockCallFor_textFieldShouldChangeCharactersInRange!(textField as! AITextField)
            }
            return true
        }
        
        // INITIAL BLANK SPACE NOT ALLOWED
        if((string == " " || string == ".") && textField.text!.characters.count == 0) {
            if (self.blockCallFor_textFieldShouldChangeCharactersInRange != nil) {
                self.blockCallFor_textFieldShouldChangeCharactersInRange!(textField as! AITextField)
            }
            return false
        }
        
        
        
        let fullText = (textField.text! as NSString).replacingCharacters(in: range, with: string);
        
        if self.textFieldType == .Text {
            
        }
        else if self.textFieldType == .Email{
            
            let c : unichar = (string as NSString).character(at: 0)
            if ((NSCharacterSet.whitespaces as NSCharacterSet).characterIsMember(c)) {
                shouldReturn = false
            }
            else {
                shouldReturn = true
            }
            
        }else if self.textFieldType == .Password{
            let c : unichar = (string as NSString).character(at: 0)
            if ((NSCharacterSet.whitespaces as NSCharacterSet).characterIsMember(c)) {
                shouldReturn = false
            }
            else {
                shouldReturn = true
            }
        }else if self.textFieldType == .Name{
            let set = NSCharacterSet(charactersIn:"ABCDEFGHIJKLMONPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz").inverted
            if(string.rangeOfCharacter(from: set) != nil || string == " "){
                shouldReturn = false
            }
        }else if self.textFieldType == .FullName{
            
            let set = NSCharacterSet(charactersIn:"ABCDEFGHIJKLMONPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ").inverted
            if(string.rangeOfCharacter(from: set) != nil){
                shouldReturn = false
            }
        }else if self.textFieldType == .CompanyName{
            
            let set = NSCharacterSet(charactersIn:"ABCDEFGHIJKLMONPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789&_-., ").inverted
            if(string.rangeOfCharacter(from: set) != nil){
                shouldReturn = false
            }
        }
        else if self.textFieldType == .AlphaNumeric{
            
            let set = NSCharacterSet(charactersIn:"ABCDEFGHIJKLMONPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ").inverted
            if(string.rangeOfCharacter(from: set) != nil){
                shouldReturn = false
            }
        }
        else if self.textFieldType == .Phone{
            
            let PHONE_REGEX = "^[1-9][0-9]*$"
            let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
            let result =  phoneTest.evaluate(with: fullText)
            
            if(result == false || string == " "){
                shouldReturn = false
            }
            
        }
        else if self.textFieldType == .WorkRadiusInkm{
            
            let PHONE_REGEX = "^[1-9]?[0-9]{1}$|^100$"
            let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
            let result =  phoneTest.evaluate(with: fullText)
            
            if(result == false || string == " "){
                shouldReturn = false
            }
            
        }
        
        if(shouldReturn == false)
        {
            if (self.blockCallFor_textFieldShouldChangeCharactersInRange != nil) {
                self.blockCallFor_textFieldShouldChangeCharactersInRange!(textField as! AITextField)
            }
            return shouldReturn
        }
        
        // GETTING FULL TEXT OF TEXTFIELD
        print("fullText \(fullText)")
        shouldReturn = fullText.characters.count <= self.maxLength;
        
        if(shouldReturn == false)
        {
            if (self.blockCallFor_textFieldShouldChangeCharactersInRange != nil) {
                self.blockCallFor_textFieldShouldChangeCharactersInRange!(textField as! AITextField)
            }
            return shouldReturn
        }
        
        if (self.blockCallFor_textFieldShouldChangeCharactersInRange != nil) {
            self.blockCallFor_textFieldShouldChangeCharactersInRange!(textField as! AITextField)
        }
        
        return shouldReturn
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        let aaa = self.getViewWithTag(aTag: self.tag + 1)
        if aaa != nil {
            
            if(aaa is AITextField || aaa is UITextField){
                _ = aaa?.becomeFirstResponder()
                
            }
            else {
                self.resignFirstResponder()
            }
        }else{
            self.resignFirstResponder()
            
        }
        
        return true
    }
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.buttonLeftPadding.isEnabled = false
        if self.blockCallFor_textFieldDidEndEditing != nil {
            self.blockCallFor_textFieldDidEndEditing!(textField as! AITextField)
        }
    }

}

