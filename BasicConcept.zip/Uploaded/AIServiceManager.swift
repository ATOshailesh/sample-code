//
//  AIServiceManager.swift
//  EduCanada

import UIKit
import Alamofire

let ServiceManager = AIServiceManager.shared


class AIServiceManager: NSObject {
    
    var currentUser:AIUser = AIUser()
    var arrAIStudentList : [AIStudentList] = [AIStudentList]()
    var arrAllInstitutionStudentList : [AIStudentList] = [AIStudentList]()
//    var arrStudentNotes : [AINotes] = [AINotes]()
	
	var request: Alamofire.Request? {
		didSet {
			oldValue?.cancel()
		}
	}
	
	// MARK: - SHARED MANAGER
	static let shared = AIServiceManager()
	
	
	//MARK:- LOGIN


    func loginWithType(type:LoginType, params:[String:Any], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String, _ user:AIUser?, _ data : NSDictionary ) -> Void){
		//let parameters:[String:Any] = [type.url:getStringFromDictionary(dict: params)]
        
        print(params)
        
//        let email = params["email"]! as! String
//        let password = params["password"]! as! String
        
//		 let url1 = "\(URL_BASE)\(type.url)&email=\(email)&password=\(password)"
        let url1 = "\(URL_BASE)\(type.url)"
		callPOSTApiWithNetCheck(url: url1, headersRequired: false, params: params) { (response, isInternetAvailable) in
			let nilDict  = NSDictionary()
			if(isInternetAvailable) {
				
				switch response!.result{
                    
				case .success(let JSON):
					print("JSON : \(JSON)")
					
					let dictJson = JSON as! NSDictionary
//					let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
					
					let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
					
					if(status == 200){
						let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
						let dictData = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "data")
                        
                        let user = AIUser(dict: dictData)
                        if user.institutionid != self.currentUser.institutionid{
                            // other institute theacher login
                            setUserDefaults(key: userDefaultKeys.studentLastSycnDate, value: "")
                            setUserDefaults(key: userDefaultKeys.noteLastSycnDate, value: "")
                        }else{
                            //same institute teacher login
                        }
                        
                        self.currentUser = user
                        AIUser.shared = user
                        
						completion(true,message,self.currentUser,JSON as! NSDictionary)
					}else{
						let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(false,message, nil,JSON as! NSDictionary)
					}
					
				case .failure(let error):
					print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,nil,nilDict)
				}
			}else{
                completion(false,INTERNET_MESSAGE,nil,nilDict)
			}
		}
	}
	
	
	
	//MARK:-
	
	/*func signupWith(params:[String:Any], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String, _ userCreated:AIUser?) -> Void){
		
		print("\nSIGNUP PARAMS : \(getStringFromDictionary(dict: params)) \n")
		
		let parameters:[String:Any] = [URL_SIGNUP:getStringFromDictionary(dict: params)]
		
		callPOSTApiWithNetCheck(url: getUrl(URL_SIGNUP) , headersRequired: false, params: parameters) { (response, isInternetAvailable) in
			
			if(isInternetAvailable) {
				
				switch response!.result{
					
				case .success(let JSON):
					print("JSON : \(JSON)")
					
					let dictJson = JSON as! NSDictionary
					let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
					
					let status = dictResponse.object_forKeyWithValidationForClass_Int(aKey: "status_code")
					
					if(status == 200){
						let message = dictResponse.object_forKeyWithValidationForClass_String(aKey: "message")
						let dictData = dictResponse.object_forKeyWithValidationForClass_NSDictionary(aKey: "data")
						let userCreated = AIUser(dict: dictData)
						
						completion(true,message,userCreated)
					}else{
						let message = dictResponse.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(false,message, nil)
					}
					
				case .failure(let error):
					print("ERR : \(error.localizedDescription)")
					completion(false,error.localizedDescription,nil)
				}
			}else{
				completion(false,INTERNET_MESSAGE,nil)
			}
		}
	}*/
	
	func forgotPasswordWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
		
//		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
		
		callPOSTApiWithNetCheck(url: getUrl(URL_FORGOT_PASSWORD) , headersRequired: false, params: params) { (response, isInternetAvailable) in
			
			if(isInternetAvailable) {
				
				switch response!.result{
					
				case .success(let JSON):
					print("JSON : \(JSON)")
					
					let dictJson = JSON as! NSDictionary
//					let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
					
					let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
					
					if(status == 200){
						let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(true,message)
					}else{
						let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(false,message)
					}
					
				case .failure(let error):
					print("ERR : \(error.localizedDescription)")
					completion(false,error.localizedDescription)
				}
			}else{
				completion(false,INTERNET_MESSAGE)
			}
		}
	}
	
	
	func changePasswordWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
		
//		let parameters:[String:Any] = [URL_CHANGE_PASSWORD:getStringFromDictionary(dict: params)]
		print(params)
        
		callPOSTApiWithNetCheck(url: getUrl(URL_CHANGE_PASSWORD) , headersRequired: true, params: params) { (response, isInternetAvailable) in
			
			if(isInternetAvailable) {
				
				switch response!.result{
					
				case .success(let JSON):
					print("JSON : \(JSON)")
					
					let dictJson = JSON as! NSDictionary
//					let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
					
					let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
					
					if(status == 200){
						let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(true,message)
					}else{
						let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(false,message)
					}
					
				case .failure(let error):
					print("ERR : \(error.localizedDescription)")
					completion(false,error.localizedDescription)
				}
			}else{
				completion(false,INTERNET_MESSAGE)
			}
		}
	}
    
    
    func offlineDataUpload(params:[String:Any], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
        
        let url = URL_BASE_POST
        callPOSTApiWithNetCheck(url: url, headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            if(isInternetAvailable) {
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    completion(true,"success")
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription)
                }
            }
        }
    }
    
    //MARK:- CALL STUDENT LIST API
    func getAllStudentList(andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String, _ data : NSDictionary ) -> Void){
              
        let url1 = "\(URL_BASE)\(GET_ALL_STUDENT_LIST)"
        callPOSTApiWithNetCheck(url: url1, headersRequired: false, params: nil) { (response, isInternetAvailable) in
            let nilDict  = NSDictionary()
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
//                    let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
//                        let dictData = dictJson.object_forKeyWithValidationForClass_NSArray(aKey: "data")
                        
//                        self.arrAIStudentList.removeAll()
//                        print(dictData.value(forKey: "dob"))
//                        
//                        for data in dictData{
//                            print(data)
//                            self.arrAIStudentList.append(AIStudentList(dict: data as! NSDictionary))
//                        }
                        
                        completion(true,message,JSON as! NSDictionary)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message ,JSON as! NSDictionary)
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,nilDict)
                }
            }else{
                completion(false,INTERNET_MESSAGE,nilDict)
            }
        }
    }
    
    
    //MARK:- CALL STUDENT LIST API
    func getAllInstitutionStudentList(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String, _ data : NSDictionary ) -> Void){
        
         print(params)
//        let url1 = "\(URL_BASE)\(GET_ALL_INSTITUTION_STUDENT)"
        let url1 = "\(URL_BASE_POST)"
        callPOSTApiWithNetCheck(url: url1, headersRequired: true, params: params) { (response, isInternetAvailable) in
            let nilDict  = NSDictionary()
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    //print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    //                    let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        let dictData = dictJson.object_forKeyWithValidationForClass_NSArray(aKey: "data")
                        
                        //self.arrAllInstitutionStudentList.removeAll()
//                        print(dictData.value(forKey: "dob"))
                        /*
                        for data in dictData{
                            //print(data)
                            self.arrAllInstitutionStudentList.append(AIStudentList(dict: data as! NSDictionary))
                        }
                        */
                        //                        let user = AIUser(dict: dictData)
                        //                        print(user)
                        print("Done API Respons.")
                        completion(true,message,JSON as! NSDictionary)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message ,JSON as! NSDictionary)
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,nilDict)
                }
            }else{
                completion(false,INTERNET_MESSAGE,nilDict)
            }
        }
    }
    
    //MARK:- CALL STUDENT API
    func getStudent(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String, _ data : NSDictionary ) -> Void){
        
        // print(params)
        
        // let email = params["email"]! as! String
        // let password = params["password"]! as! String
        
        let url1 = "\(URL_BASE)\(GET_STUDENT)"
        
        callPOSTApiWithNetCheck(url: url1, headersRequired: false, params: params) { (response, isInternetAvailable) in
            let nilDict  = NSDictionary()
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        let data = dictJson.object_forKeyWithValidationForClass_NSArray(aKey: "data").firstObject as! NSDictionary
            
                        completion(true,message,data)
                        
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message ,JSON as! NSDictionary)
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,nilDict)
                }
            }else{
                completion(false,INTERNET_MESSAGE,nilDict)
            }
        }
    }
    
    //MArk:- Call save student API
    func saveStudentWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
        
        
        callPOSTApiWithNetCheck(url: getUrl(SAVE_STUDENT) , headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(true,message)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message )
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription)
                }
            }else{
                completion(false,INTERNET_MESSAGE)
            }
        }
    }

    
    
    func searchStudentWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String,_ data: NSArray) -> Void){
        
        //		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
        
        callPOSTApiWithNetCheck(url: getUrl(GET_ALL_STUDENT_LIST) , headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            let nilArray = NSArray()
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    //                    let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        let dictData = dictJson.object_forKeyWithValidationForClass_NSArray(aKey: "data")
                        
                        self.arrAIStudentList.removeAll()
                        for data in dictData{
                            print(data)
                            self.arrAIStudentList.append(AIStudentList(dict: data as! NSDictionary))
                        }
                        completion(true,message,dictData)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message,nilArray)
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,nilArray)
                }
            }else{
                completion(false,INTERNET_MESSAGE,nilArray)
            }
        }
    }
    
    func getAllNotesWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String,_ last_sync_date: String, _ data: NSArray) -> Void){
        
        //		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
        
        let url = "\(URL_BASE_POST)"
        //getUrl(GET_STUDENT_NOTES_INSTITUTION
        print(params)
        
        callPOSTApiWithNetCheck(url: url , headersRequired: false, params: params) { (response, isInternetAvailable) in
        
            let nilArray = NSArray()
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    //print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    let last_sync_date = dictJson.object_forKeyWithValidationForClass_String(aKey: "last_sync_date")
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        let dictData = dictJson.object_forKeyWithValidationForClass_NSArray(aKey: "data")
                        
                        //self.arrStudentNotes.removeAll()
                        /*for data in dictData{
                            print(data)
                            self.arrStudentNotes.append(AINotes(dict: data as! NSDictionary))
                        }*/
                        completion(true,message,last_sync_date,dictData)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        
                        completion(false,message,last_sync_date,nilArray )
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,"",nilArray)
                }
            }else{
                completion(false,INTERNET_MESSAGE,"",nilArray)
            }
        }
    }
    
    func getStudentNotesWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String,_ data: NSArray) -> Void){
        
        //		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
        
        callPOSTApiWithNetCheck(url: getUrl(GET_STUDENT_NOTES) , headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            let nilArray = NSArray()
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    //                    let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        let dictData = dictJson.object_forKeyWithValidationForClass_NSArray(aKey: "data")
                        
                        completion(true,message,dictData)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message,nilArray)
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription,nilArray)
                }
            }else{
                completion(false,INTERNET_MESSAGE,nilArray)
            }
        }
    }
    
    func addNotesWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
        
        //		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
        
        callPOSTApiWithNetCheck(url: getUrl(ADD_NOTES) , headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(true,message)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message )
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription)
                }
            }else{
                completion(false,INTERNET_MESSAGE)
            }
        }
    }
    
    func editNotesWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
        
        //		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
        
        callPOSTApiWithNetCheck(url: getUrl(EDIT_NOTES) , headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(true,message)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message )
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription)
                }
            }else{
                completion(false,INTERNET_MESSAGE)
            }
        }
    }
    
    func deleteNotesWith(params:[String:String], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
        
        //		let parameters:[String:Any] = [URL_FORGOT_PASSWORD:getStringFromDictionary(dict: params)]
        print("Param : ",params)
        callPOSTApiWithNetCheck(url: getUrl(DELETE_NOTE) , headersRequired: false, params: params) { (response, isInternetAvailable) in
            
            if(isInternetAvailable) {
                
                switch response!.result{
                    
                case .success(let JSON):
                    print("JSON : \(JSON)")
                    
                    let dictJson = JSON as! NSDictionary
                    
                    let status = dictJson.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    
                    if(status == 200){
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(true,message)
                    }else{
                        let message = dictJson.object_forKeyWithValidationForClass_String(aKey: "message")
                        completion(false,message )
                    }
                    
                case .failure(let error):
                    print("ERR : \(error.localizedDescription)")
                    completion(false,error.localizedDescription)
                }
            }else{
                completion(false,INTERNET_MESSAGE)
            }
        }
    }
    
	
	/*func logoutWith(params:[String:Any], andCompletion completion:@escaping (_ isSuccess:Bool, _ message:String) -> Void){
		
		let parameters:[String:Any] = [:]
		
		callGETApiWithNetCheck(url: getUrl(URL_LOGOUT) , headersRequired: true, params: parameters) { (response, isInternetAvailable) in
			
			if(isInternetAvailable) {
				
				switch response!.result{
					
				case .success(let JSON):
					print("JSON : \(JSON)")
					
					let dictJson = JSON as! NSDictionary
					let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
					
					let status = dictResponse.object_forKeyWithValidationForClass_Int(aKey: "status_code")
					
					if(status == 200){
						let message = dictResponse.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(true,message)
					}else{
						let message = dictResponse.object_forKeyWithValidationForClass_String(aKey: "message")
						completion(false,message)
					}
					
				case .failure(let error):
					print("ERR : \(error.localizedDescription)")
					completion(false,error.localizedDescription)
				}
			}else{
				completion(false,INTERNET_MESSAGE)
			}
		}
	}*/
	
	
	
	//MARK:- ******** COMMON POST METHOD *********
	
	private func callGETApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?, completionHandler : @escaping (DataResponse<Any>?,Bool) -> Void){
		callGET_POSTApiWithNetCheck(isGet: true, url: url, headersRequired: headersRequired, params: params, completionHandler: completionHandler)
	}

	private func callPOSTApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?, completionHandler : @escaping (DataResponse<Any>?,Bool) -> Void){
		callGET_POSTApiWithNetCheck(isGet: false, url: url, headersRequired: headersRequired, params: params, completionHandler: completionHandler)
	}
	
    private func callGET_POSTApiWithNetCheck(isGet:Bool, url : String, headersRequired : Bool, params : [String : Any]?, completionHandler : @escaping (DataResponse<Any>?,Bool) -> Void){
        
        if(!IS_INTERNET_AVAILABLE()){
            SHOW_INTERNET_ALERT()
            completionHandler(nil,false)
            return
        }
//        Alamofire.request(url, method: .post, parameters: params, encoding: URLEncoding.httpBody, headers: nil).responseString(completionHandler: { (response) in
//            print(response)
//        })
        
//    Alamofire.SessionManager.default.session.configuration.timeoutIntervalForRequest = 120
       Alamofire.request(url, method: .post, parameters: params, encoding: URLEncoding.httpBody, headers: nil).responseJSON { (response) in
        
        
            //print(response)
            switch response.result{
                
            case .success(let JSON):
                
                
                if JSON is NSDictionary
                {
                    let dictJson = JSON as! NSDictionary
                    let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
                    let status = dictResponse.object_forKeyWithValidationForClass_Int(aKey: "status_code")
                    if(status == 103){
                        self.handleInvalidAccessToken()
                    }else{
                        completionHandler(response,true)
                    }
                    
                }
                else
                {
                    print("J S O N \(JSON)")
                    completionHandler(response,false)
                    
                }
                
            case .failure( _):
                completionHandler(response,true)
            }
            
        }
    }
	
//	private func callGET_POSTApiWithNetCheck(isGet:Bool, url : String, headersRequired : Bool, params : [String : Any]?, encoding:String, completionHandler : @escaping (DataResponse<Any>?,Bool) -> Void){
//		
//		if(!IS_INTERNET_AVAILABLE()){
//			SHOW_INTERNET_ALERT()
//			completionHandler(nil,false)
//			return
//		}
//		var headers:[String:String] = [:]
//		if headersRequired {
//			headers["user_id"] = SharedUser.idUser
//			headers["device_id"] = SharedUser.deviceId
//			headers["access_token"] = SharedUser.accessToken
//		}
//		print("\n\n\n\n\nURL : \(url) \nPARAM : \(getStringFromDictionary(dict: params!)) \nHEADERS : \(getStringFromDictionary(dict: headers))")
//		
//		let parameterEncoding = encoding == "" ? URLEncoding.default : URLEncoding.queryString
//		
//		Alamofire.request(url, method: isGet ? .get : .post, parameters: params, encoding: parameterEncoding, headers: headers).responseJSON { (response) in
//
//			switch response.result{
//			case .success(let JSON):
//				let dictJson = JSON as! NSDictionary
//				let dictResponse = dictJson.object_forKeyWithValidationForClass_NSDictionary(aKey: "response")
//				let status = dictResponse.object_forKeyWithValidationForClass_Int(aKey: "status_code")
//				if(status == 103){
//					self.handleInvalidAccessToken()
//				}else{
//					completionHandler(response,true)
//				}
//			case .failure( _):
//				completionHandler(response,true)
//			}
//		}
//	}
	
	
	private func handleInvalidAccessToken(){
	
		HIDE_CUSTOM_LOADER()
		HIDE_NETWORK_ACTIVITY_INDICATOR()

        AIAlertController.shared.displayAlertWithTitle(title: APPNAME, andMessage: "Session expired ! Just login again", buttons: ["OK"]) { (index) in
            
        }
        
		/*showAlertWithTitleFromVC(vc: (appDelegate.window?.rootViewController)!, title: APP_NAME, andMessage: "Session expired ! Just login again", buttons: ["OK"]) { (index) in
			SharedUser.logOutLocally(with: { (isSuccess, message) in
				appDelegate.changeRootToLoginVC()
			})
		}*/
	}
	//MARK:- ******** COMMON MULTIPART METHOD *********
	
	
	
	private func callUPLOADApiWithNetCheck(url : String, image:UIImage?, headersRequired : Bool, params : [String : Any]?, completionHandler : @escaping (DataResponse<Any>?,Bool) -> Void){
		
		if(!IS_INTERNET_AVAILABLE()){
			SHOW_INTERNET_ALERT()
			completionHandler(nil,false)
			return
		}
		
		var headers:[String:String] = [:]
		if headersRequired {
			headers["user_id"] = SharedUser.teacherid
			//headers["device_id"] = SharedUser.deviceId
			//headers["access_token"] = SharedUser.accessToken
		}

		print("\n\n\n\n\nURL : \(url) \nPARAM : \(getStringFromDictionary(dict: params!)) \nHEADERS : \(getStringFromDictionary(dict: headers))")

		SHOW_NETWORK_ACTIVITY_INDICATOR()

		Alamofire.upload(multipartFormData:{ multipartFormData in

			if let params = params {
				for eachKey in params.keys {
					if let value = params[eachKey] as? String {
						multipartFormData.append(value.data(using: .utf8)!, withName: eachKey)
					}
				}
			}
			
			if let image = image {
				if let imageData = UIImageJPEGRepresentation(image, 1) {
					multipartFormData.append(imageData, withName: "image", fileName: "image.jpg", mimeType: "image/jpeg")
				}
			}
		},
		 usingThreshold:UInt64.init(),
		 to:url,
		 method:.post,
		 headers:headers,
		 encodingCompletion: { encodingResult in
			
			HIDE_NETWORK_ACTIVITY_INDICATOR()

			switch encodingResult {
			case .success(let upload, _, _):
				upload.responseJSON { response in
					completionHandler(response,true)
				}
			case .failure(let encodingError):
				print("ERR: UPLOAD: \(encodingError.localizedDescription)")
				completionHandler(nil,true)
			}
		})
	}

	func cancellAllPendingRequests(){
		
		let sessionManager = Alamofire.SessionManager.default;
		
		sessionManager.session.getTasksWithCompletionHandler { dataTasks, uploadTasks, downloadTasks in

			print("\n\n")
			
			dataTasks.forEach({ (task) in
                print("1 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
			})

			dataTasks.forEach({ (task) in
                print("2 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
			})

			dataTasks.forEach({ (task) in
                print("3 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
			})

			
			dataTasks.forEach { $0.cancel() }
			uploadTasks.forEach { $0.cancel() }
			downloadTasks.forEach { $0.cancel() }
		}
	}
	
}
