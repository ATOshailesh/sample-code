//
//  BaseViewController.swift
//  CarSumers
//

import UIKit
import NVActivityIndicatorView
import SDWebImage

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.setRightBarItem()
        
    }

    
   
    
    // MARK: - Navigation Title
    
    func setNavigationTitle(strTitle : String)
    {
        self.navigationItem.title = strTitle
       /* let titleDict: NSDictionary = [NSAttributedStringKey.foregroundColor: UIColor.green,NSAttributedStringKey.font: UIFont.appFont_SemiBold(fontSize: 18)]
        self.navigationController?.navigationBar.titleTextAttributes = titleDict as? [NSAttributedStringKey : AnyObject]*/
    }
    
    func hideBackButton(isHide : Bool)
    {
        self.navigationItem.setHidesBackButton(isHide, animated:false);
        if !isHide {
            let yourBackImage = UIImage(named: "backarrow")
//            self.navigationController?.navigationBar.backIndicatorImage = yourBackImage
//            self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = yourBackImage
            self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: yourBackImage, style: .plain, target: self, action: #selector(popViewController))
         }
    }
    
    @objc func popViewController()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func hideNavigationBar(isHide : Bool)
    {
        self.navigationController?.isNavigationBarHidden = isHide
    }
    
    func setRightBarItem()
    {
//        let btn = UIButton(type: .custom)
//
//      //  btn.backgroundColor = UIColor.red
//
//        if AIUser.sharedManager.image_id.isEmpty
//        {
//            // placeholder image
//            btn.setImage(#imageLiteral(resourceName: "userplaceholder"), for: .normal)
//        }
//        else
//        {
//            let url : String = "http://180.211.99.165:8080/jaisal/car_sumers/api/assets/user_images/" + AIUser.sharedManager.profile_picture
//             btn.sd_setImage(with: URL(string: url), for: .normal, placeholderImage: #imageLiteral(resourceName: "userplaceholder"), options: SDWebImageOptions.refreshCached, completed: nil)
//        }
//        btn.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
////
//      // btn.imageView?.contentMode = .scaleAspectFit
//        btn.applyCircle()
    //    btn.clipsToBounds = true
     //   btn.layer.masksToBounds = true
        
        let img : UIImageView = UIImageView()
       
        let url : String = "http://180.211.99.165:8080/jaisal/car_sumers/api/assets/user_images/" + AIUser.sharedManager.profile_picture
        img.sd_setImage(with: URL(string: url), placeholderImage: #imageLiteral(resourceName: "userplaceholder"), options: SDWebImageOptions.refreshCached, completed: nil)
         img.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        img.widthAnchor.constraint(equalToConstant: 34).isActive = true
        img.heightAnchor.constraint(equalToConstant: 34).isActive = true
        img.contentMode = .scaleToFill
        img.clipsToBounds = true
        img.applyCircle()
        let rightBarButton = UIBarButtonItem(customView: img)
        rightBarButton.customView?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(profileClick)))
        self.navigationItem.rightBarButtonItem = rightBarButton
        
    }
    
    func hideTabBar(isHide : Bool)
    {
        self.tabBarController?.tabBar.isHidden = isHide
    }
    
    // MARK: - Button Actions
    
    @objc func profileClick()
    {
        let profileVC : ProfileViewController = ProfileViewController.loadController() //self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
        profileVC.isComeFromTab = false
        self.hideTabBar(isHide: true)
        self.navigationController?.pushViewController(profileVC, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func goToTabbar()
    {
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let tabbarController : TabBarController = mainStoryboard.instantiateViewController(withIdentifier: "TabBarController") as! TabBarController
        UIApplication.shared.keyWindow?.rootViewController = tabbarController
        UIView.transition(with: Constant.appDelegate.window!, duration: 0.5, options: UIViewAnimationOptions.transitionCrossDissolve, animations: nil, completion: nil)
    }
    
    func goToLogin(){
        let loginVC = LoginViewController.loadController()
        UIApplication.shared.keyWindow?.rootViewController = UINavigationController(rootViewController: loginVC)
    }

    func forceFullyLogoutApp(strMessage : String)
    {
        showAlertWithTitleFromVC(vc: self, title: Constant.App.APP_NAME, andMessage: strMessage, buttons: ["OK"]) { (tag) in
            self.logoutFromApp()
        }
    }
    
    func logoutFromApp()
    {
        AIUser.sharedManager.logout()
        removeFolder(strFolderName: Constant.folderName.pdfs)
        self.goToLogin()
    }
    
    
}

extension BaseViewController : NVActivityIndicatorViewable
{
    // MARK: - Show loader
    func showActivityIndicator(withText text: String) {
        let size = CGSize(width: 60, height:60)
        
        startAnimating(size, message: text, type: NVActivityIndicatorType.ballScaleMultiple, color: UIColor.white, padding: nil, displayTimeThreshold: nil, minimumDisplayTime: nil)
    }
    
    //MARK: - hideloader
    func hideActivityIndicator() {
        stopAnimating()
    }
}
